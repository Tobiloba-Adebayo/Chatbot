document.addEventListener("DOMContentLoaded", function() {
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');

    sendBtn.addEventListener('click', function() {
        const userMessage = userInput.value.trim();
        if (userMessage === '') return;

        displayMessage(userMessage, 'user');
        getBotResponse(userMessage);

        userInput.value = '';
    });

    function displayMessage(message, sender) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', `${sender}-message`);
        messageElement.innerText = message;
        chatBox.appendChild(messageElement);

        // Auto-scroll to bottom
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    async function getBotResponse(question) {
        try {
            const response = await fetch('answers.json');
            const data = await response.json();
            const answers = data.questions;

            for (let i = 0; i < answers.length; i++) {
                if (question.toLowerCase() === answers[i].question.toLowerCase()) {
                    displayMessage(answers[i].answer, 'bot');
                    return;
                }
            }

            displayMessage("I'm sorry, I don't understand that question.", 'bot');
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
});
